%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-21T21:05:31+08:00*%
%TF.ProjectId,RF111_ANT_PARASITIC_A04,52463131-315f-4414-9e54-5f5041524153,A04*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-21 21:05:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H1*%
X37000000Y-73000000D03*
%TD*%
%TO.C,H2*%
X73000000Y-73000000D03*
%TD*%
%TO.C,H3*%
X73000000Y-37000000D03*
%TD*%
%TO.C,H4*%
X37000000Y-37000000D03*
%TD*%
M02*
